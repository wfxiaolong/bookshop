define(['app', 'js/utils/tips'], function(app, Tips) {
    app.controller('feeDetailCtrl', ['$scope', 'httpRequest', 'Storage', '$state', '$ionicPopup',
        function($scope, httpRequest, Storage, $state, $ionicPopup) {
           
        }
    ]);

});
