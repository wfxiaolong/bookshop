define(['app', 'js/utils/tips'], function(app, Tips) {
    app.controller('studentListCtrl', ['$scope', 'httpRequest', 'Storage', '$state', '$ionicPopup',
        function($scope, httpRequest, Storage, $state, $ionicPopup) {
           
        }
    ]);

});
