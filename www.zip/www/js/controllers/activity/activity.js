define(['app', 'js/utils/tips'], function(app, Tips) {
    app.controller('activityCtrl', ['$scope', 'httpRequest', 'Storage', '$state', '$ionicPopup',
        function($scope, httpRequest, Storage, $state, $ionicPopup) {
           $scope.changeType = function(index) {
                $scope.type = index;
            };
        }
    ]);

});
